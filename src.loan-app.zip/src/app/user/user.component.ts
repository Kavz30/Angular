import { Component, DoCheck, OnInit } from '@angular/core';
import { LogService } from '../log.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit,DoCheck {

  constructor(private data: LogService) { }
  msg:any=[];
  ngDoCheck(): void {
   
      this.msg=this.data.callData();
    
  }

 
  ngOnInit(): void {
  }
  send(msg:any)
  {

    this.msg=this.data.getData("user:"+msg);
    this.msg=`user:${msg}`;
  }

}
