import { Component, DoCheck, OnInit } from '@angular/core';
import { LogService } from '../log.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit,DoCheck {

  constructor(private data1:LogService) { }

  msg:any=[];
  ngOnInit(): void {
  }
 
  ngDoCheck(): void {
   
      this.msg=this.data1.callData();
    
  }
  send(msg:any)
  {

    this.msg=this.data1.getData("admin:"+msg);
    this.msg=`admin:${msg}`;
  }

}
