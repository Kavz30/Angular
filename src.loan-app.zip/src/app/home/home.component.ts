import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
 
export class HomeComponent implements OnInit {
  interest:any=0;
 

  constructor() { }

  ngOnInit(): void {
  }
  
  demo(val1:number,val2:number)
  {
     
   this.interest=(val1*val2*0.04)/100;
    return `${this.interest}`;
  }
  demo1(val1:number,val2:number)
  {
     
   this.interest=(val1*val2*0.07)/100;
    return `${this.interest}`;
  }
  demo2(val1:number,val2:number)
  {
     
   this.interest=(val1*val2*0.09)/100;
    return `${this.interest}`;
  }
  flag:boolean=false;
  name:string="kaviya";
  password:string="123";
  
  change(val1:string,val2:string){
    if(this.name==val1&&this.password==val2)
    {
      if(this.flag)
      {
        this.flag=!this.flag;
      }
      else{
        this.flag=!this.flag;
      }
    }
   
  }
  flag1:boolean=false;
  flag2:boolean=false;
  
  change1(){
    if(this.flag1)
    {
      this.flag1=!this.flag1;
    }
    else{
      this.flag1=!this.flag1;
    }
  }
  chat()
  {
    if(this.flag2)
    {
      this.flag2=!this.flag2;
    }
    else{
      this.flag2=!this.flag2;
    }
  }

}
