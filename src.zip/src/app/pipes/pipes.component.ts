import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pipes',
  templateUrl: './pipes.component.html',
  styleUrls: ['./pipes.component.css']
})
export class PipesComponent implements OnInit {
 name:string='demo Text';
 date:Date=new Date();
 amount:number=20000;
 value:number=2;
 value1:number=3;
  constructor() { }

  ngOnInit(): void {
  }

}
