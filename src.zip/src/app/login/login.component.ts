import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  msg:string='';
  valid:boolean=true;
  prop:string='';
  demo:any=[
    {'email':'kaviya@gmail.com','password':1234},
    {'email':'priya@gmail.com','password':123},
    {'email':'sanju@gmail.com','password':333}
  ]
  constructor() { }

  ngOnInit(): void {
  }
  login(value:any){

    if(value.email=="kaviya@gmail.com" && value.password==123)
    {
      this.msg="login successfull";
      this.prop='green';
    }
    else{
      this.msg="login not succesfull";
      this.prop='blue';
    }
  }

}
